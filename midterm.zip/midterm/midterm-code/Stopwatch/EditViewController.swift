//
//  EditViewController.swift
//  Stopwatch
//
//  Created by Ashley Blacquiere
//  Copyright © 2019 Your School. All rights reserved.
//

import UIKit

protocol EditViewControllerDelegate: class {
    func editViewController(_ controller: EditViewController, didFinishEditing items: UIColor)
    
//    func changeTheColor(color : Bool)
}

class EditViewController: UIViewController {
    
    weak var delegate: EditViewControllerDelegate?
    
    
//    var items: Bool = false
    
    var items : UIColor = UIColor.init()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
    }
    
    @IBAction func colors(){
        items = UIColor.orange
        print("colors button pressed \(items)")
    }
//    @IBAction func done() {
//        
//        delegate?.editViewController(self, didFinishEditing: items)
//    
//    }

}
